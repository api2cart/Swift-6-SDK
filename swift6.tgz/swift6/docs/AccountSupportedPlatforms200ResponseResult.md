# AccountSupportedPlatforms200ResponseResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supportedPlatforms** | [AccountSupportedPlatforms200ResponseResultSupportedPlatformsInner] |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


