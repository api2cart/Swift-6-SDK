# AttributeValueDelete200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnCode** | **Int** |  | [optional] 
**returnMessage** | **String** |  | [optional] 
**result** | [**AttributeValueDelete200ResponseResult**](AttributeValueDelete200ResponseResult.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


